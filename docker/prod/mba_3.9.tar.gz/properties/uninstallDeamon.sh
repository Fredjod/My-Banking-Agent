launchctl unload ~/Library/LaunchAgents/com.fred.mba.launchd.plist
rm ~/Library/LaunchAgents/com.fred.mba.launchd.plist