use warnings;
use strict;
our %auth = (
	'MARC.KEY' => ['marclogin', 'marcpwd'],
	'SOPHIE.KEY' => ['sophielogin', 'sophiepwd'],	
	);
1;
